# Dialectic — Astra investigation package

Start with `DIALECTIC_INVESTIGATIVE_FEATURE_BRIEF.md`.

The `assets/` directory contains four visual explorations. The numbered wireframe (`04_...`) is the primary visual reference; the other images illustrate temporal navigation, guided presentation and creative multi-perspective responses.

This package commissions **investigation and qualification only**. It does not authorise implementation until the user reviews Astra's findings.
