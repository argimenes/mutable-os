# Dialectic — Investigative Feature Brief

**Project:** Mutable OS / Mutable Ink  
**Application:** Dialectic  
**Status:** Design intent and investigative commission — **not** authorisation to implement  
**Date:** 6 November 2026  
**Audience:** Astra (architecture investigation, qualification and incremental implementation proposal)

## 0. Executive mandate

Design **Dialectic**, a first-class Mutable OS application for structured, non-linear human–AI and human–human dialogue. A conversation is **not** merely an append-only visual chat transcript, a reply tree, or a force-directed graph. It is a chronological record of authored, addressable contributions with independently recorded referential relationships, Gloss/metasemantic strata, and optional **authored presentation sequences**. Participants must be able to revisit any earlier moment, respond to a Block or precise range, conduct an extended side exchange, and return to the current chronological frontier without losing context.

**The key creative requirement:** a participant, including an AI, may compose responses using the *full expressive resources of Mutable Ink*: ordinary Blocks, multi-column arrangements, comparisons, carousels, diagrams, media, and guided stepwise presentation. Do not reduce AI output to a `response-block` or a fixed set of chat cards.

**Deliverable requested from Astra now:** inspect the actual repository, qualify reuse and gaps, identify schema/API/view contracts and risks, and propose a small staged implementation. Do **not** launch a broad implementation or exhaustive test campaign without approval.

## 1. Motivation and problem

Long assistant responses frequently contain six or more separately discussable points. A human reader can only respond to a fraction at once; unaddressed points become stranded in history. Flat chat also conflates (a) when a reply was created, (b) what it addresses, and (c) how the recipient should encounter it. A person may return to an earlier passage hours later, annotate it, unpack a tangent for many exchanges, then return to the present informed by that work. Dialectic must make these activities natural and persistent.

The application must support rich discussion *within* the same knowledge environment as Mutable Documents, Entities, Claims, Relationships and Glosses, not establish an incompatible conversation store or parallel editor.

## 2. Non-negotiable conceptual invariants

1. **Chronology:** every contribution/event has a stable creation order. A reply to old content is created **now**, not inserted retroactively into the historical event stream.
2. **Reference:** replies, challenges, elaborations, gestures and syntheses point to specific existing contributions, Blocks, text ranges, Glosses or other resolvable targets. Referential ancestry is not chronological order.
3. **Presentation:** an author may arrange references and newly authored content in a separate delivery order; this does not reorder or duplicate canonical source content.
4. **Composition:** every contribution can be a structured Mutable Document fragment, not just a string. Its constituent Blocks have stable identities.
5. **Reader agency:** guided presentation can propose attention and order but never trap the reader. They can interrupt, annotate, reply, navigate freely, and resume their previous presentation position.
6. **Interpretive multiplicity:** Glosses can overlap, remain uncertain, and coexist with conversation replies; an unresolved gesture need not be forcibly resolved.
7. **No destructive reparenting:** navigating, presenting or replying must not silently move or rewrite source Blocks. A reply whose anchor is invalidated must remain recoverable.
8. **Existing app views protected:** new Dialectic views may be tailored to Desktop/Textual/etc. Do not retrofit existing Flint views in ways that degrade them.

## 3. Core domain concepts — conceptual, to be mapped to actual repository types

### 3.1 Conversation
A durable container of participants, ordered contribution events, relationships, sequences and optional conversation-level metadata. The chronological ledger is canonical; a conversation is not defined by its currently selected view.

### 3.2 Contribution
An authored, time-stamped, stable-identity event containing or referring to an ordinary Mutable Document fragment / set of Blocks. A contribution may consist of a single sentence, several paragraphs, a carousel, or a complex multi-pane composition. Distinguish contribution identity from Block identity. A contribution's visible content can be a composition of existing and new Blocks where ownership/reference semantics permit.

### 3.3 Anchors and targets
At minimum: contribution, Block and precise text range; investigate future compatibility with Gloss, Document and Entity references, plus unresolved semantic gestures. **Do not replace the existing standoff range machinery** with a parallel implementation. Investigate anchor offset maintenance, deletion, orphan recovery and cross-document addressing.

### 3.4 Conversational relationships
Initial: `replies-to` with a stable target. Future candidates: `elaborates`, `challenges`, `revisits`, `synthesises`, `references`. A synthesis may have multiple targets; do not encode the domain as a strictly single-parent tree even if v1 UI only permits one primary reply target. Avoid making all relationships Glosses.

### 3.5 Gloss
Metasemantic strata over text, including uncertainty, phrase variants, deliberate ambiguity, local definitions, excluded interpretations, provisional references and gestures. A Gloss is not synonymous with a conversational reply. A reply is an authored conversational contribution; a Gloss expresses a property or interpretation of content. Both may target the same passage and may be mutually referential where supported.

### 3.6 Sequence
A first-class, authored **presentation plan**, separate from the contribution and its chronological placement. It can arrange new content and references to earlier Blocks in deliberate order. Candidate declarative operations: `show`, `focus`, `compare`, `reveal`, `annotate`, `navigate`, `branch`, `return`. Do not invent an imperative UI scripting language. Sequence steps must themselves be addressable/repliable, or provide stable mappings to the Blocks and ranges they present. Sequence content remains available outside guided mode.

### 3.7 Three positions and two cursors
- **Chronological frontier / present:** latest committed event, irrespective of what is being inspected.
- **Inspection cursor:** passage, contribution or event currently being read or edited.
- **Presentation cursor:** current step in an authored Sequence, if active.

Also preserve ordinary navigation Back/Forward history, which is distinct from chronological history. Returning to Present is not the same as returning to Sequence.

## 4. Functional application wireframe: nine regions

See `assets/04_dialectic_application_wireframe.png` for the numbered reference. The illustration is **conceptual**, not a pixel-perfect UI specification. Its content and numbering correspond to the following responsibilities.

| # | Region | Purpose | Functional requirements |
|---|---|---|---|
| 1 | Application navigation | Switch projections of one conversation | Conversation / focused exchange, Sequence, Temporal Map, Document; preserve selection and navigation state |
| 2 | Conversation sidebar | Structural orientation | Conversation metadata, contributions, threads, sequences, Glosses, participants, unresolved items; collapsible |
| 3 | Contribution header | Provenance and context | Speaker/author, time, contribution identity, referenced targets, active sequence/step |
| 4 | Sequence progress | Guided delivery | Current step, previous/next, step overview, pause/exit/resume; only when a Sequence is active |
| 5 | Creative response canvas | Primary reading and expressive surface | Host **ordinary Mutable Block compositions**: prose, layouts, carousels, comparison panels, diagrams, tables, media, nested arrangements; no hardcoded AI card grammar |
| 6 | Synthesis / transition | Optional authored content | A conclusion, transition, question or synthesis may appear where the author places it; not a mandatory fixed summary panel |
| 7 | Composer | Write/reply/gloss | Use existing editor functionality; target Block, range, step, contribution or present; permit rich structured response; show target clearly |
| 8 | Context inspector | Local references and interpretation | Source excerpts, reply chains, Glosses, related contributions, provenance, navigation actions, optional candidate targets |
| 9 | Temporal navigator | Orientation across time and excursions | Monotonic chronological spine, historical reply/reference excursions, current inspection and present, jump/return; compact/collapsible |

**Layout behaviour:** panels should be resizeable/collapsible where feasible. Region 5 gets priority. Sequence UI should disappear for ordinary unguided exchanges. Mobile/narrow screens should not require three simultaneous columns. The temporal navigator should not dominate the reading area.

## 5. Primary interaction flows

### A. Reply to a precise earlier passage
1. Navigate to an earlier contribution; select a Block or text range.
2. Invoke Reply; composer visibly identifies its target (and optional surrounding context).
3. Write a short or complex response using Mutable Ink.
4. Commit a **new present-time contribution** whose reply relation targets the earlier passage.
5. Show the reply alongside its source in a focused view; do not insert the event retroactively into chronology.

### B. Conduct an extended excursion
1. Select a reply and respond recursively, potentially many times.
2. Keep the source, branch ancestry and chronological positions recoverable.
3. Jump to another older point, or navigate elsewhere in the document.
4. Return to previous inspection location, Sequence step or chronological present independently.

### C. Deliver a creative multi-point response
1. Author a contribution containing a multi-column comparison, carousel, or other Block composition.
2. Include source excerpts **by reference** and newly authored explanation.
3. Provide clear speaker/provenance cues and per-Block/range Reply and Gloss actions.
4. Allow recipient to inspect any presented source in its original context.

### D. Deliver a guided Sequence
1. Author an ordered series of steps referring to source passages and/or new Block compositions.
2. Recipient advances at their own pace; may skip or inspect the full outline.
3. At any step, recipient can interrupt to ask a question, reply to a precise range, or attach a Gloss.
4. A side exchange does not overwrite presentation state. `Return to Sequence` restores the paused step; `Return to Present` goes to the chronological frontier.
5. Free reading mode exposes all contributions without requiring playback.

### E. Synthesis across distant branches
1. Select or reference multiple earlier passages/threads.
2. Compose a new contribution at the present with typed `synthesises` or equivalent references.
3. Display its references and original contexts without pretending it is a child of just one old message.

### F. Gloss a conversation
1. Select a phrase inside any human or AI contribution.
2. Create a Gloss such as `variant`, `uncertain`, `gesture`, `not`, `means`, `poly` or a user-defined type as supported by the current Gloss registry.
3. Preserve original text matrix and attach standoff strata.
4. Expose the Gloss in the inspector; do not confuse it with a reply.

## 6. View projections

### 6.1 Focused exchange / paired reading — likely default
Source material remains visible with attached replies in an adjacent rail. The rail can show replies-to-replies; selection changes the focus without moving canonical content. Clearly distinguish human and AI contributions using label/icon/shape, not colour alone.

### 6.2 Creative composition / Sequence
Region 5 renders the actual authored layout, including carousel or side-by-side perspectives. Sequence controls propose an order, and may progressively reveal content. The user can freely inspect, annotate and branch at any point. An optional presentation/full-screen view may reuse the same Sequence data.

### 6.3 Chronology
A reliable ordered event feed, including new replies to older material. Each event has a visible target/backlink. Essential for catching up and reconstructing what happened.

### 6.4 Temporal map
Time is monotonic and spatially stable where practical; referential excursions link back to older targets. Prefer a constrained incremental layout over force-directed global rearrangement. Explore whether a timeline + local branch layout or ELK-assisted subgraph arrangement is suitable. Do not commit to ELK or a graph renderer without inspecting current facilities.

### 6.5 Document / outline
Read or edit the underlying structured content in a conventional Mutable document-oriented projection, retaining links to contributions and Glosses.

### 6.6 Workspace presentation compatibility
Investigate the existing universal application presentation contract. Dialectic should support a Desktop-specific view initially, with a viable route to Textual (cell-based) and other workspaces. Custom views are preferable to damaging existing app presentations.

## 7. AI interaction and context protocol

AI participation is a first-class participant, not a monolithic message append operation. For each request, assemble **bounded, relevant** context from the selected target, its owning contribution, ancestor replies, surrounding document Blocks, pertinent Glosses, relevant related branches and optionally user-selected sources. Preserve provenance and distinction between asserted fact, tentative Gloss, unresolved reference and AI-generated interpretation.

AI output must support a structured, validated Document fragment and optional declarative Sequence plan / reply references. The host, not the model, should validate target IDs, assign canonical IDs, commit content, and reject unsafe/invalid structural operations. Streaming partial content should not create dangling committed references. Inspect the actual model/API integration and current structured-output capabilities before selecting an implementation protocol.

**AI proposals are not authority:** generated Glosses, relationship candidates and inferred target resolutions must be distinguishable from author-accepted content.

## 8. UI design details and edge cases

- Distinguish human and assistant by author labels/icons and subtle consistent treatments; no giant speech bubbles or colour-only differentiation.
- Source Block / selected range should be unmistakable in the reply composer.
- Handle a range spanning multiple text Blocks only if the current editor supports it reliably; otherwise explicitly scope v1.
- Deleted/edited source: retain orphaned reply with cached excerpt/provenance and a recovery action; never silently delete discussion.
- Replies to replies: no arbitrary visual indentation that eventually becomes unreadable; use focus/rail/ancestry controls.
- Multiple simultaneous points of view: comparisons and carousels are compositions, not a bespoke special-case message type.
- A Sequence step can present multiple source ranges and multiple new Blocks.
- Presentation and inspection cursors can diverge; the UI must communicate both.
- Chronology remains intact when a branch is continued after hours or days.
- Gloss metadata and reply relationships should survive export/import if the relevant format supports them; identify scope and gaps.
- Consider accessibility, keyboard navigation, zoom, responsive layouts, focus management and low-motion behaviour.
- A Sequence's original authored order must remain recoverable if later edited; investigate versioning only, defer implementation.
- No assumptions about collaboration, permissions, live multi-user synchronization or concurrent editing in v1.

## 9. Candidate data contracts (illustrative only)

```ts
interface DialogueConversation {
  guid: string;
  contributionGuids: string[]; // chronological order, or derived from event index
}
interface DialogueContribution {
  guid: string;
  authorGuid: string;
  createdAt: string;
  documentFragmentGuid: string;
}
type DialogueTarget =
  | { kind: 'contribution'; contributionGuid: string }
  | { kind: 'block'; blockGuid: string }
  | { kind: 'text-range'; blockGuid: string; start: number; end: number }
  | { kind: 'gloss'; glossGuid: string }
  | { kind: 'unresolved'; description: string };
interface DialogueRelation {
  guid: string;
  sourceContributionGuid: string;
  targets: DialogueTarget[];
  kind: 'replies-to' | 'references' | 'synthesises' | 'revisits' | 'challenges';
}
interface DialogueSequence {
  guid: string;
  authorGuid: string;
  steps: DialogueSequenceStep[];
}
type DialogueSequenceStep =
  | { guid: string; kind: 'show'; blockGuids: string[] }
  | { guid: string; kind: 'focus'; target: DialogueTarget }
  | { guid: string; kind: 'compare'; targets: DialogueTarget[] }
  | { guid: string; kind: 'reveal'; blockGuids: string[] }
  | { guid: string; kind: 'branch'; sequenceGuid: string };
```

**Do not implement these types verbatim.** Map onto actual Mutable persistence and Block, Document, Relationship, Gloss and standoff APIs. Avoid new parallel ID schemes and premature normalisation.

## 10. Repository investigation requested from Astra

Provide concrete file paths and concise evidence for:

1. Existing Instrument/application registration and presentation/view contracts (including Desktop/Textual separation).
2. Flint's structured Block editing, rendering, nested layouts, carousels, comparisons, media and document fragments.
3. Stable Block identity, text-range/standoff offsets, edit tracking, deletion behaviour and cross-document references.
4. Gloss Mode / Gloss Explorer data model, relationship editor, metadata, indexing and any structured payload support.
5. Window manager, selection, navigation history, focus/spotlight, panel docking, keyboard shortcuts and layout infrastructure.
6. Existing persistence, event/chronology facilities and transactions/undo semantics.
7. Current AI request/response adapters, streaming and structured outputs.
8. Existing graph/temporal layout libraries and likely performance constraints.
9. Import/export, schema migration and backward-compatibility constraints.

For each, distinguish **already reusable**, **requires adaptation**, **missing**, and **uncertain**. Ask targeted questions rather than filling gaps with assumptions.

## 11. Proposed small delivery gates — for qualification, not automatic execution

**Gate A — Repository qualification and thin architecture proposal.** Map reuse/gaps, choose minimal data model, identify risks and ask for decisions. No UI build.

**Gate B — Vertical slice: addressable dialogue.** New Dialectic app shell; two participants (human + AI adapter or mocked assistant); ordinary structured contribution Blocks; block-level replies; chronology; focused source/reply view; Return to Present. Use existing editor, not a textarea clone.

**Gate C — Rich composition and range targets.** Text-range replies; Gloss integration; authored multi-column/carousel content; source backlinks; anchor recovery; keyboard navigation. Only after confirming existing renderer reuse.

**Gate D — Guided Sequences.** Declarative sequence steps, focus/compare/reveal, interruption/resumption, presentation cursor independent of inspection and present, free reading fallback.

**Gate E — Temporal navigator and multi-target synthesis.** Constrained time-based map, stable layout, multi-source references and branch synthesis. Keep graph embellishment optional.

**Gate F — Qualification and refinement.** Focused smoke/regression checks, responsive/accessibility assessment, performance at realistic discussion sizes; documentation. No blanket large-scale test matrix unless evidence warrants it.

Astra should recommend collapsing or rearranging gates where existing infrastructure makes that sensible. **Avoid overengineering, multi-day ceremonial plans and token-expensive exhaustive tests.** Each gate should yield a demonstrable usable increment.

## 12. Acceptance scenarios

1. User replies to an AI paragraph from the beginning of a conversation; the reply is recorded at the chronological frontier and remains attached to the old Block.
2. User annotates a word in that reply with a variant Gloss; original text is preserved and Gloss is visible in context.
3. AI responds with a multi-column comparison referencing two distant user passages and a new synthesis Block; each constituent Block remains addressable.
4. AI delivers a four-step Sequence; user pauses at step two, branches into several exchanges, jumps to another topic, and returns to step two.
5. Return to Present goes to the latest event rather than the most recently inspected parent or the current Sequence step.
6. Chronology and referential structure show consistent but distinct positions for all events.
7. Deleting/changing source text does not silently destroy a reply or strand it invisibly.
8. Existing Flint Desktop and Textual views continue to work as before.

## 13. Explicit non-goals for initial implementation

- Full collaborative multiplayer editing, real-time synchronization and permissions.
- AI autonomy in revising existing author content.
- General-purpose force-directed graph as the default interface.
- A universal semantic ontology for every kind of Gloss.
- Semantic revision history or branch auto-clustering.
- Full visual scripting language for presentation.
- Rebuilding Flint, Block renderer, Gloss infrastructure or window manager.
- Pixel-perfect reproduction of exploratory image mockups.

## 14. Assets and interpretation

- `assets/01_early_conversation_temporal_map.png`: first exploration of focused conversation, context and temporal map.
- `assets/02_guided_sequence_comparison.png`: step-based presentation comparing distant source passages.
- `assets/03_creative_carousel_response.png`: a structured response with simultaneous perspectives and carousel/sequence controls.
- `assets/04_dialectic_application_wireframe.png`: numbered nine-region functional wireframe; **primary visual reference**.

The screenshots are **design explorations**, not a requirement to reproduce their exact typography, invented counts, labels, colours or visual density. In particular, the wireframe's 'Synthesis' area is illustrative, not a fixed compulsory response component. The implementation must favour Mutable's real presentation contracts and native Block composition.

## 15. Requested Astra response format

Return one concise qualification document with:

1. **Architecture inventory** (file paths, actual reusable components, gaps).
2. **Recommended minimal model** (how it fits current tables/types; migrations only if necessary).
3. **UI composition proposal** (nine regions, focus/sequence/chronology/map projections; responsive and Textual considerations).
4. **AI integration contract** (context assembly, structured output, validation, IDs, streaming).
5. **Risks / ambiguities requiring user decision**, ranked by impact.
6. **Smallest viable implementation plan**, estimated relative effort, limited tests and a proposed first vertical slice.

**Stop after the investigation and await approval before implementation.**
